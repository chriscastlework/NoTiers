

public class AomObjectViewModel 
{

public Guid ID {get;set;}
public Guid AOMMetaID {get;set;}
public string Name {get;set;}

}



