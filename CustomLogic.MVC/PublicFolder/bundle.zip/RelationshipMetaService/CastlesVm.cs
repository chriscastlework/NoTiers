

public class RelationshipMetaViewModel 
{

public Guid ID {get;set;}
public Guid PkAOMMetaID {get;set;}
public Guid FkAOMMetaID {get;set;}
public Guid FkAOMFieldMetaID {get;set;}
public Guid RelationshipTypeID {get;set;}

}



