

public class RelationshipObjectViewModel 
{

public Guid ID {get;set;}
public Guid RelationshipMetaID {get;set;}
public Guid PkAOMFieldObjectID {get;set;}
public Guid FkAOMFieldObjectID {get;set;}

}



