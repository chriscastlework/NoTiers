

public class RelationshipTypesViewModel 
{

public Guid ID {get;set;}
public string Name {get;set;}

}



