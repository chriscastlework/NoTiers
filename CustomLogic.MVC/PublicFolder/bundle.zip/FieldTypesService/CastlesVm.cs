

public class FieldTypesViewModel 
{

public Guid ID {get;set;}
public string Name {get;set;}

}



