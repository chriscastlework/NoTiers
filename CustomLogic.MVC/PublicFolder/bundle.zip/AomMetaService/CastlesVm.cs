

public class AomMetaViewModel 
{

public Guid ID {get;set;}
public string Name {get;set;}

}



