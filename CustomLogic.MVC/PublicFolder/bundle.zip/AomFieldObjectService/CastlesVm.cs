

public class AomFieldObjectViewModel 
{

public Guid ID {get;set;}
public Guid AOMObjectID {get;set;}
public Guid AOMFieldMetaID {get;set;}
public string Value {get;set;}

}



