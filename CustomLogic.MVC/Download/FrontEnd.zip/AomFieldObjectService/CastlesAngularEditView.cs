
<div class="form">
<input type="text" ng-model={{ID}} />
<input type="text" ng-model={{AomObjectId}} />
<input type="text" ng-model={{AomFieldMetaId}} />
<input type="text" ng-model={{Value}} />
<div/>
