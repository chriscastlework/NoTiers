
<div class="form">
<input type="text" ng-model={{ID}} />
<input type="text" ng-model={{RelationshipMetaId}} />
<input type="text" ng-model={{PkAomFieldObjectId}} />
<input type="text" ng-model={{FkAomFieldObjectId}} />
<div/>
