
<div class="form">
<input type="text" ng-model={{ID}} />
<input type="text" ng-model={{PkAomMetaId}} />
<input type="text" ng-model={{FkAomMetaId}} />
<input type="text" ng-model={{FkAomFieldMetaId}} />
<input type="text" ng-model={{Name}} />
<input type="text" ng-model={{PkAomFieldMetaId}} />
<div/>
