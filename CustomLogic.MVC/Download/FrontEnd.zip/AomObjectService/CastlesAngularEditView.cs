
<div class="form">
<input type="text" ng-model={{ID}} />
<input type="text" ng-model={{AomMetaId}} />
<input type="text" ng-model={{Name}} />
<div/>
