
<div class="form">
<input type="text" ng-model={{MigrationId}} />
<input type="text" ng-model={{ContextKey}} />
<input type="text" ng-model={{Model}} />
<input type="text" ng-model={{ProductVersion}} />
<div/>
