using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CustomLogic;
using CustomLogic.Core.Interfaces;
using CustomLogic.Core.Models;
using CustomLogic.Services.BuyingProcessesService;


public class BuyingProcessesController : Controller
{
    //private AomDbContext db = new AomDbContext();
    private readonly IService<BuyingProcessesViewModel>_BuyingProcessesService = new BuyingProcessesService(new DbContext());


        // GET: BuyingProcesses
        public ActionResult Index()
        {
        return View(_BuyingProcesses
        Service.List(new NgTableParams() {page = 1, count = 1000}, null).Data.ToList());
        }

        // GET: BuyingProcesses/Details/5
        public ActionResult Details(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        return View(_BuyingProcesses
        Service.View(new BuyingProcesses
        ViewModel() { ID = id.Value}, null));
        }

        // GET: BuyingProcesses/Create
        public ActionResult Create()
        {
        return View();
        }

        // POST: BuyingProcesses/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name")] BuyingProcesses
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result =_BuyingProcesses
        Service.Insert(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it went wrong?
        }

        return View(aomMeta);
        }

        // GET: BuyingProcesses
        s/Edit/5
        public ActionResult Edit(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _BuyingProcesses
        Service.View(new BuyingProcesses
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: BuyingProcesses
        s/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name")] BuyingProcesses
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result = _BuyingProcesses
        Service.Update(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it goes wrong?
        }
        return View(aomMeta);
        }

        // GET: BuyingProcesses
        s/Delete/5
        public ActionResult Delete(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _BuyingProcesses
        Service.View(new BuyingProcesses
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: BuyingProcesses
        s/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
        var result = _BuyingProcesses
        Service.Delete(new BuyingProcesses
        ViewModel {ID = id}, null);
        return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
        if (disposing)
        {
        // _BuyingProcesses
        Service = null; // make services disposeable?
        }
        base.Dispose(disposing);
        }
        }


