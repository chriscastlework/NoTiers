using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CustomLogic;
using CustomLogic.Core.Interfaces;
using CustomLogic.Core.Models;
using CustomLogic.Services.UserFoldersService;


public class UserFoldersController : Controller
{
    //private AomDbContext db = new AomDbContext();
    private readonly IService<UserFoldersViewModel>_UserFoldersService = new UserFoldersService(new DbContext());


        // GET: UserFolders
        public ActionResult Index()
        {
        return View(_UserFolders
        Service.List(new NgTableParams() {page = 1, count = 1000}, null).Data.ToList());
        }

        // GET: UserFolders/Details/5
        public ActionResult Details(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        return View(_UserFolders
        Service.View(new UserFolders
        ViewModel() { ID = id.Value}, null));
        }

        // GET: UserFolders/Create
        public ActionResult Create()
        {
        return View();
        }

        // POST: UserFolders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name")] UserFolders
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result =_UserFolders
        Service.Insert(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it went wrong?
        }

        return View(aomMeta);
        }

        // GET: UserFolders
        s/Edit/5
        public ActionResult Edit(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _UserFolders
        Service.View(new UserFolders
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: UserFolders
        s/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name")] UserFolders
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result = _UserFolders
        Service.Update(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it goes wrong?
        }
        return View(aomMeta);
        }

        // GET: UserFolders
        s/Delete/5
        public ActionResult Delete(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _UserFolders
        Service.View(new UserFolders
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: UserFolders
        s/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
        var result = _UserFolders
        Service.Delete(new UserFolders
        ViewModel {ID = id}, null);
        return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
        if (disposing)
        {
        // _UserFolders
        Service = null; // make services disposeable?
        }
        base.Dispose(disposing);
        }
        }


