using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CustomLogic;
using CustomLogic.Core.Interfaces;
using CustomLogic.Core.Models;
using CustomLogic.Services.CustomFieldValidationsService;


public class CustomFieldValidationsController : Controller
{
    //private AomDbContext db = new AomDbContext();
    private readonly IService<CustomFieldValidationsViewModel>_CustomFieldValidationsService = new CustomFieldValidationsService(new DbContext());


        // GET: CustomFieldValidations
        public ActionResult Index()
        {
        return View(_CustomFieldValidations
        Service.List(new NgTableParams() {page = 1, count = 1000}, null).Data.ToList());
        }

        // GET: CustomFieldValidations/Details/5
        public ActionResult Details(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        return View(_CustomFieldValidations
        Service.View(new CustomFieldValidations
        ViewModel() { ID = id.Value}, null));
        }

        // GET: CustomFieldValidations/Create
        public ActionResult Create()
        {
        return View();
        }

        // POST: CustomFieldValidations/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name")] CustomFieldValidations
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result =_CustomFieldValidations
        Service.Insert(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it went wrong?
        }

        return View(aomMeta);
        }

        // GET: CustomFieldValidations
        s/Edit/5
        public ActionResult Edit(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _CustomFieldValidations
        Service.View(new CustomFieldValidations
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: CustomFieldValidations
        s/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name")] CustomFieldValidations
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result = _CustomFieldValidations
        Service.Update(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it goes wrong?
        }
        return View(aomMeta);
        }

        // GET: CustomFieldValidations
        s/Delete/5
        public ActionResult Delete(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _CustomFieldValidations
        Service.View(new CustomFieldValidations
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: CustomFieldValidations
        s/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
        var result = _CustomFieldValidations
        Service.Delete(new CustomFieldValidations
        ViewModel {ID = id}, null);
        return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
        if (disposing)
        {
        // _CustomFieldValidations
        Service = null; // make services disposeable?
        }
        base.Dispose(disposing);
        }
        }


