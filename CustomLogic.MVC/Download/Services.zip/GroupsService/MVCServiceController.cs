using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CustomLogic;
using CustomLogic.Core.Interfaces;
using CustomLogic.Core.Models;
using CustomLogic.Services.GroupsService;


public class GroupsController : Controller
{
    //private AomDbContext db = new AomDbContext();
    private readonly IService<GroupsViewModel>_GroupsService = new GroupsService(new DbContext());


        // GET: Groups
        public ActionResult Index()
        {
        return View(_Groups
        Service.List(new NgTableParams() {page = 1, count = 1000}, null).Data.ToList());
        }

        // GET: Groups/Details/5
        public ActionResult Details(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        return View(_Groups
        Service.View(new Groups
        ViewModel() { ID = id.Value}, null));
        }

        // GET: Groups/Create
        public ActionResult Create()
        {
        return View();
        }

        // POST: Groups/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name")] Groups
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result =_Groups
        Service.Insert(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it went wrong?
        }

        return View(aomMeta);
        }

        // GET: Groups
        s/Edit/5
        public ActionResult Edit(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _Groups
        Service.View(new Groups
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: Groups
        s/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name")] Groups
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result = _Groups
        Service.Update(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it goes wrong?
        }
        return View(aomMeta);
        }

        // GET: Groups
        s/Delete/5
        public ActionResult Delete(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _Groups
        Service.View(new Groups
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: Groups
        s/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
        var result = _Groups
        Service.Delete(new Groups
        ViewModel {ID = id}, null);
        return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
        if (disposing)
        {
        // _Groups
        Service = null; // make services disposeable?
        }
        base.Dispose(disposing);
        }
        }


