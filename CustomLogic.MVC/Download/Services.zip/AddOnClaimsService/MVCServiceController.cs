using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CustomLogic;
using CustomLogic.Core.Interfaces;
using CustomLogic.Core.Models;
using CustomLogic.Services.AddOnClaimsService;


public class AddOnClaimsController : Controller
{
    //private AomDbContext db = new AomDbContext();
    private readonly IService<AddOnClaimsViewModel>_AddOnClaimsService = new AddOnClaimsService(new DbContext());


        // GET: AddOnClaims
        public ActionResult Index()
        {
        return View(_AddOnClaims
        Service.List(new NgTableParams() {page = 1, count = 1000}, null).Data.ToList());
        }

        // GET: AddOnClaims/Details/5
        public ActionResult Details(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        return View(_AddOnClaims
        Service.View(new AddOnClaims
        ViewModel() { ID = id.Value}, null));
        }

        // GET: AddOnClaims/Create
        public ActionResult Create()
        {
        return View();
        }

        // POST: AddOnClaims/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name")] AddOnClaims
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result =_AddOnClaims
        Service.Insert(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it went wrong?
        }

        return View(aomMeta);
        }

        // GET: AddOnClaims
        s/Edit/5
        public ActionResult Edit(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _AddOnClaims
        Service.View(new AddOnClaims
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: AddOnClaims
        s/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name")] AddOnClaims
        ViewModel aomMeta)
        {
        if (ModelState.IsValid)
        {
        var result = _AddOnClaims
        Service.Update(aomMeta, null);
        if(result.Success)
        return RedirectToAction("Index");

        // what if it goes wrong?
        }
        return View(aomMeta);
        }

        // GET: AddOnClaims
        s/Delete/5
        public ActionResult Delete(Guid? id)
        {
        if (id == null)
        {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
        var result = _AddOnClaims
        Service.View(new AddOnClaims
        ViewModel {ID = id.Value}, null);
        if (!result.Success)
        {
        return HttpNotFound();
        }
        return View(result.Data);
        }

        // POST: AddOnClaims
        s/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
        var result = _AddOnClaims
        Service.Delete(new AddOnClaims
        ViewModel {ID = id}, null);
        return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
        if (disposing)
        {
        // _AddOnClaims
        Service = null; // make services disposeable?
        }
        base.Dispose(disposing);
        }
        }


