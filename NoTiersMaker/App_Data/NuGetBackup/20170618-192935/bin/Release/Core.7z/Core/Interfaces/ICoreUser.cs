﻿using Microsoft.AspNet.Identity;

namespace CustomLogic.Core.Interfaces
{
    /// <summary>
    /// Some basic user information will need to be decieded on each project
    /// </summary>
    public interface ICoreUser : IUser
    {
        int OrganisationId();
    }
}
