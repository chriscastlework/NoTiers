﻿Core Framework - Disscusssion is required before any major changes inside this folder

ICoreUser - should be defined at the start of each project 